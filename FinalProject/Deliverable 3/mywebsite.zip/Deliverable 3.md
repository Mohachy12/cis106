![Resume Picture](pexels-dinielle-de-veyra-4195342.jpg)
# Mohammed M. Chowdhury

<hr>

**Life Goal**

My ultimate goal is to acquire a fulfilling career in IT so that I can provide my family with a secure and comfortable life. I am satisfied with that as my  goal, wanting nothing more than to be able to provide for my family. I used to have dreams of playing professional soccer, but now my priorities are to make my parents proud. All I aim for is their happiness and my capacity to meet their needs.

<hr>

## Experince 
### Bengal Pharmacy
**Pharmacy Technician** 9/10/2018 - 11/20/2023
As experienced technician and the manager of a technical team at Bengal Pharmacy, I excel at organizing smooth operations, using technical expertise to improve systems, and motivating team members to work together. My leadership guarantees that workflows are efficient and that technical performance is of a high standard.

<hr>


## Education
### Passaic County Community College 
**Network Admin** - 2021 - Present


### John Of Kennedy High School
**High School Diploma** - 2020

<hr>


## Skills

**Leadership** - I lead and supervise a technical team, making sure that goals are clear and tasks are assigned efficiently to achieve them.

**Communication** - My position at Bengal Pharmacy involves maintaining open lines of communication within the technical team, supporting smooth information flow, and ensuring everyone is on the same page with our objectives.

**Organization** -  handle Bengal Pharmacy's technical operations, making use of my excellent organizational skills to improve operations and distribute resources wisely.



<hr>
